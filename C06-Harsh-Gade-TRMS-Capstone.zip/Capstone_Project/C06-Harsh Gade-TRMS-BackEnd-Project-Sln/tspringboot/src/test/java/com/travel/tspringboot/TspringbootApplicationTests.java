package com.travel.tspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
