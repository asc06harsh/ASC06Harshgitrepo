export class TripData {
  id: string ='';
  name: string = '';
  startDate: string = '';
  endDate: string = '';
  price: number = 0;
  image: string = '';
}
