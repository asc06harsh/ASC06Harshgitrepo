export class PaymentData {
    id: number = 0;
    description: string = '';
    amount: number = 0;
    date: string = '';
  }
  