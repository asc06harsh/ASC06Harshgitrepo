export class Feedback {
    id: number = 0;
    name: string = '';
    email: string = '';
    message: string = '';
  }
  