export class CabData {
    id: number = 0;
    model: string = '';
    licensePlate: string = '';
    capacity: number = 0;
    pricePerDay: number = 0;
  }
  