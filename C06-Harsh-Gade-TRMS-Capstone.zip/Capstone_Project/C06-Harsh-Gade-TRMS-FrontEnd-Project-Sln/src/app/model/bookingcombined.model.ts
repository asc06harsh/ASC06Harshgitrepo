export class BookingCombinedData {
    id!: number;
    customerName!: string;
    tripName!: string;
    cabModel!: string;
    bookingDate!: string;  // Updated to bookingDate
    totalPrice!: number;
  }
  
  